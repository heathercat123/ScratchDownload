#include "ScratchOps.h"

#include <windows.h>
#include <objbase.h>
#include <shlobj.h>
#include <shellapi.h>
#include <winuser.h>

#define true 1
#define false 0

void OpenURL(char *url) {
	ShellExecute(NULL, "open", url, NULL, NULL, SW_SHOWNORMAL);
}

void SetScratchWindowTitle(char *title) {
	HWND w = GetActiveWindow();
	SetWindowText(w, title);
}

// Constants were missing from the VS98 header files:
#define CSIDL_PROFILE		0x28
#define CSIDL_MYDOCUMENTS	0x05
#define CSIDL_MYPICTURES	0x27
#define CSIDL_MYMUSIC		0x0D

void GetFolderPathForID(int folderID, char *path, int maxPath) {
	char folderPath[_MAX_PATH];
	int fType;
	HRESULT ok;

	path[0] = 0;  // zero-length return value indicates failure

	switch(folderID){
	case 1: fType = CSIDL_PROFILE; break;
	case 2: fType = CSIDL_DESKTOP; break;
	case 3: fType = CSIDL_MYDOCUMENTS ; break;
	case 4: fType = CSIDL_MYPICTURES ; break;
	case 5: fType = CSIDL_MYMUSIC ; break;
	default: if (folderID > 0) return;
	}

	// the following line allows direct experimentation with
	// windows CSIDL's by passing a negative folderID
	if (folderID <= 0) fType = -folderID;

	ok = SHGetSpecialFolderPath(NULL, folderPath, fType, false);

	if (ok) strncpy(path, folderPath, maxPath);
}

int WinShortToLongPath(char *shortPath, char* longPath, int maxPath) {
//old:	int result = GetFullPathName(shortPath, maxPath, longPath, NULL);
	int result = GetLongPathName(shortPath, longPath, maxPath);
	if ((result >= maxPath) || (result == 0)) return -1;  // failed
	return 0;
}

int IsFileOrFolderHidden(char *fullPath) {
	DWORD attributes = GetFileAttributes(fullPath);
	if (attributes == -1) return false;
	return (attributes & (FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM)) != 0;
}

void SetUnicodePasteBuffer(short int *utf16, int count) {
	/* does nothing on Windows */
}
